package com.pojos.userdetails;

public class Bookingdates {
    public String checkin;
    public String checkout;
}
