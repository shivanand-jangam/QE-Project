package com.pojos.userdetails;

public class GenerateTokenPOJO {
	
	private String token;
	
	    public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

		
	

}
