package com.pojos.userdetails;

public class GitHubTest {

	public void testGit() {
		System.out.println("Added Test comment Github");
	}

	public void testGit2() {
		System.out.println("Chnaaged as per review comment Github2");
	}

}
